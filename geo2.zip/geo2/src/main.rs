use std::time::Instant;

use rstar::{RTree, RTreeObject, AABB, PointDistance};

#[derive(Clone, Debug)]
struct Store {
    location: [f64; 2],
    name: String,
}

impl RTreeObject for Store {
    type Envelope = AABB<[f64; 2]>;

    fn envelope(&self) -> Self::Envelope {
        AABB::from_point(self.location)
    }
}

impl PointDistance for Store {
    fn distance_2(&self, point: &[f64; 2]) -> f64 {
        // rstar::euclidean_distance_2(self.location, point)
        let dx = self.location[0] - point[0];
        let dy = self.location[1] - point[1];
        dx * dx + dy * dy
    }
}

fn main() {
    let start = Instant::now();
    let mut tree = RTree::new();
    for i in 0..360_0000 {
        let latitude = -90f64 + (i as f64) / 2_0000f64;
        let longitude = -180f64 + i as f64 / 1_0000f64;
        tree.insert(Store {
            location: [latitude, longitude],
            name: format!("Store {}", i),
        });
    }
    let duration = start.elapsed();
    println!("Add took {:?} seconds", duration.as_secs_f64());

    let start = Instant::now();
    let query_point = [0f64, 0f64]; // 加州中心
    let nearest_stores: Vec<_> = tree
        .nearest_neighbor_iter(&query_point)
        .take(30)
        .collect();
    let duration = start.elapsed();
    println!("Search took {:?} seconds", duration.as_secs_f64());

    for store in nearest_stores {
        println!("Found store: {} at {:?}", store.name, store.location);
    }
}
