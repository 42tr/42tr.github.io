use geohash::{encode, neighbor};
use std::{cmp::Ordering, collections::HashMap, time::Instant};
use once_cell::sync::Lazy;
use std::sync::Mutex;

const FIND_NUM: usize = 30;
static HASH_LEN: usize = 9;

static GEOHASH_MAP: Lazy<Mutex<HashMap<String, Vec<Location>>>> = Lazy::new(|| Mutex::new(HashMap::new()));

#[derive(Debug, Clone)]
struct Location {
    name: String,
    latitude: f64,
    longitude: f64,
}

// 计算两点之间的球面距离（单位：米）
fn haversine_distance(lat1: f64, lon1: f64, lat2: f64, lon2: f64) -> f64 {
    const EARTH_RADIUS: f64 = 6371e3; // 地球半径（单位：米）

    let lat1_rad = lat1.to_radians();
    let lon1_rad = lon1.to_radians();
    let lat2_rad = lat2.to_radians();
    let lon2_rad = lon2.to_radians();

    let delta_lat = lat2_rad - lat1_rad;
    let delta_lon = lon2_rad - lon1_rad;

    let a = (delta_lat / 2.0).sin().powi(2)
        + lat1_rad.cos() * lat2_rad.cos() * (delta_lon / 2.0).sin().powi(2);
    let c = 2.0 * a.sqrt().atan2((1.0 - a).sqrt());

    EARTH_RADIUS * c
}

fn insert(name: String, latitude: f64, longitude: f64) {
    let geohash = encode(geohash::Coord { x: longitude, y: latitude }, HASH_LEN).unwrap();
    let mut map = GEOHASH_MAP.lock().unwrap();
    let prefix = geohash.to_string();
    let entry = map.entry(prefix).or_insert(vec![]);
    entry.push(Location {
        name: name.clone(),
        latitude,
        longitude,
    });
}

/// 获取最近的商店，此处考虑向外扩张次数不多，如果存在某块区域附近没有商店导致效率低，可增加缓存提前处理提高速度
fn get_locations(geohash: &str) -> Vec<Location> {
    let mut locations = vec![];
    let map = GEOHASH_MAP.lock().unwrap();

    let mut norths = vec![neighbor(&geohash, geohash::Direction::N).unwrap()];
    let mut north_east = neighbor(&geohash, geohash::Direction::NE).unwrap();
    let mut easts = vec![neighbor(&geohash, geohash::Direction::E).unwrap()];
    let mut south_east = neighbor(&geohash, geohash::Direction::SE).unwrap();
    let mut souths = vec![neighbor(&geohash, geohash::Direction::S).unwrap()];
    let mut south_west = neighbor(&geohash, geohash::Direction::SW).unwrap();
    let mut wests = vec![neighbor(&geohash, geohash::Direction::W).unwrap()];
    let mut north_west = neighbor(&geohash, geohash::Direction::NW).unwrap();
    if let Some(entry) = map.get(geohash) {
        locations.extend(entry.iter().cloned());
    }
    loop {
        let mut norths_new = vec![];
        let mut souths_new = vec![];
        let mut easts_new = vec![];
        let mut wests_new = vec![];
        norths.iter().for_each(|f| {
            if let Some(entry) = map.get(f) {
                locations.extend(entry.iter().cloned());
            }
            norths_new.push(neighbor(f, geohash::Direction::N).unwrap());
        });
        souths.iter().for_each(|f| {
            if let Some(entry) = map.get(f) {
                locations.extend(entry.iter().cloned());
            }
            souths_new.push(neighbor(f, geohash::Direction::S).unwrap());
        });
        easts.iter().for_each(|f| {
            if let Some(entry) = map.get(f) {
                locations.extend(entry.iter().cloned());
            }
            easts_new.push(neighbor(f, geohash::Direction::E).unwrap());
        });
        wests.iter().for_each(|f| {
            if let Some(entry) = map.get(f) {
                locations.extend(entry.iter().cloned());
            }
            wests_new.push(neighbor(f, geohash::Direction::W).unwrap());
        });
        if let Some(entry) = map.get(&north_east) {
            locations.extend(entry.iter().cloned());
        }
        norths_new.push(neighbor(&north_east, geohash::Direction::N).unwrap());
        easts_new.push(neighbor(&north_east, geohash::Direction::E).unwrap());
        north_east = neighbor(&north_east, geohash::Direction::NE).unwrap();
        if let Some(entry) = map.get(&south_east) {
            locations.extend(entry.iter().cloned());
        }
        souths_new.push(neighbor(&south_east, geohash::Direction::S).unwrap());
        easts_new.push(neighbor(&south_east, geohash::Direction::E).unwrap());
        south_east = neighbor(&south_east, geohash::Direction::SE).unwrap();
        if let Some(entry) = map.get(&south_west) {
            locations.extend(entry.iter().cloned());
        }
        souths_new.push(neighbor(&south_west, geohash::Direction::S).unwrap());
        wests_new.push(neighbor(&south_west, geohash::Direction::W).unwrap());
        south_west = neighbor(&south_west, geohash::Direction::SW).unwrap();
        if let Some(entry) = map.get(&north_west) {
            locations.extend(entry.iter().cloned());
        }
        norths_new.push(neighbor(&north_west, geohash::Direction::N).unwrap());
        wests_new.push(neighbor(&north_west, geohash::Direction::W).unwrap());
        north_west = neighbor(&north_west, geohash::Direction::NW).unwrap();

        norths = norths_new;
        souths = souths_new;
        easts = easts_new;
        wests = wests_new;
        if locations.len() >= FIND_NUM {
            return locations;
        }
    }
}

fn find(latitude: f64, longitude: f64) -> Vec<Location> {
    let geohash = encode(geohash::Coord { x: longitude, y: latitude }, HASH_LEN).unwrap();
    let mut locations = get_locations(&geohash);
    locations.sort_by(|a, b| haversine_distance(a.latitude, a.longitude, latitude, longitude).partial_cmp(&haversine_distance(b.latitude, b.longitude, latitude, longitude)).unwrap_or(Ordering::Equal));
    locations.into_iter().take(FIND_NUM).collect()
}


fn main() {
    for i in 0..3600_0000 {
        let latitude = -90f64 + (i as f64) / 20_0000f64;
        let longitude = -180f64 + i as f64 / 10_0000f64;
        insert(format!("location{}", i), latitude, longitude);
    }
    let start = Instant::now();
    let mut locations = find(0f64, 0f64);
    let duration = start.elapsed();
    println!("Function took {:?} seconds", duration.as_secs_f64());

    locations.sort_by(|a, b| a.name.cmp(&b.name));
    
    println!("{:?}", locations);
    println!("{}", locations.len());
}
