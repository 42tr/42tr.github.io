use tantivy::schema::*;
use tantivy::{doc, Index};
use tantivy::query::FuzzyTermQuery;
use tantivy::collector::TopDocs;
use std::path::Path;
use std::sync::Arc;
use std::time::Instant;
use pinyin::ToPinyin;

const FIND_NUM: usize = 10;

fn create_or_load_index(index_path: &str, names: &[String]) -> tantivy::Result<Index> {
    let path = Path::new(index_path);

    // 定义索引 schema
    let mut schema_builder = Schema::builder();
    schema_builder.add_text_field("name", TEXT | STORED); // 原始名称
    schema_builder.add_text_field("pinyin", TEXT | STORED); // 拼音
    let schema = schema_builder.build();

    let index = if path.exists() {
        Index::open_in_dir(path)?
    } else {
        std::fs::create_dir(path)?;
        let index = Index::create_in_dir(path, schema.clone())?;
        let mut index_writer = index.writer(50_000_000)?;

        // 添加数据到索引
        for name in names {
            let pinyin = name.as_str().to_pinyin().next().unwrap().unwrap().plain();
            let _ = index_writer.add_document(doc! {
                schema.get_field("name").unwrap() => name.as_str(),
                schema.get_field("pinyin").unwrap() => pinyin,
            });
        }
        index_writer.commit()?;
        index
    };
    Ok(index)
}

fn search_similar_names(index: &Index, input: &str) -> tantivy::Result<Vec<String>> {
    let reader = index.reader()?;
    let searcher = reader.searcher();

    let schema = index.schema();
    let name_field = schema.get_field("name").unwrap();
    let pinyin_field = schema.get_field("pinyin").unwrap();
    let input_pinyin = input.to_pinyin().next().unwrap().unwrap().plain();

    // 构造模糊查询
    let query = FuzzyTermQuery::new(
        tantivy::Term::from_field_text(pinyin_field, input_pinyin),
        0, // 最大编辑距离，控制模糊成都
        true,
    );

    let top_docs = searcher.search(&query, &TopDocs::with_limit(FIND_NUM))?;
    let mut results = Vec::new();
    for (_score, doc_address) in top_docs {
        let retrieved_doc = searcher.doc(doc_address)?;
        let name = retrieved_doc.get_first(name_field).unwrap().as_text().unwrap();
        results.push(name.to_string());
    }
    Ok(results)
}

fn main() {
    let index_path = "tantivy_index";
    let mut names = vec![];
    for i in 0..10_0000 {
        let str = format!("张三{}", i);
        names.push(str);
        let str = format!("李四{}", i);
        names.push(str);
    }

    // 创建索引
    let start = Instant::now();
    let index = Arc::new(create_or_load_index(index_path, &names).unwrap());
    let duration = start.elapsed();
    println!("Create took {:?} seconds", duration.as_secs_f64());

    // 搜索
    let start = Instant::now();
    let results = search_similar_names(&index, "长伞风").unwrap();
    let duration = start.elapsed();
    println!("Search took {:?} seconds", duration.as_secs_f64());
    println!("{:?}", results);
}
